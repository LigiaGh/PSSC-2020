﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StackUnderflow.Domain.Core.Contexts.Question.CreateQuestionFolder
{
    public class CreateQuestionAdapter
    {
    }
}
