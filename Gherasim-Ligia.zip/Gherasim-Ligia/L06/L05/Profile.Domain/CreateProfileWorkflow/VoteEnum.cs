﻿namespace Profile.Domain.CreateProfileWorkflow
{
    public enum VoteEnum
    {
        Up = 1,
        Down = -1
    }
}